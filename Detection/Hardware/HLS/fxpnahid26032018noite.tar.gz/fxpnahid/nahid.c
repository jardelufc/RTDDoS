#include <stdio.h>
#include <math.h>
#include <stdlib.h>

short fxpnahid(short x1,short x2,short x3,short y1, short y2, short y3);

void main(void) {

   
   short x1, x2, x3, y1, y2, y3,z;

   x1=365;
   x2=3;
   x3=1;
   y1=379;
   y2=3;
   y3=1;

/*
   x1=357663.0;
   x2=12.79;
   x3=0.94;
   y1=379.0;
   y2=2.55;
   y3=0.9709;*/
 
   z=fxpnahid(x1,x2,x3,y1,y2,y3);
   printf("%d",z);

}


short fxpnahid(short x1,short x2,short x3,short y1, short y2, short y3)
{

	short ax1,ay1,Mx,My,mx1,mx2,mx3,my1,my2,my3,Mx2,My2,amx1,amy1,M2x,M2y,Vx,Vy,SDx,SDy,MSDx,MSDy,DX1,DX2,DX3,DY1,DY2,DY3,D1,D2,D3,N1,N2,N3;
	short Q1,Q2,Q3,aQ1,aQ2,NaHiDverc;
	ax1=x1+x2; 
	ay1=y1+y2;
 	Mx=(ax1+x3)/4;
	My=(ay1+y3)/4;
	mx1=x1*x1;
	mx2=x2*x2;
	mx3=x3*x3;
	my1=y1*y1;
	my2=y2*y2;
	my3=y3*y3;
	Mx2=Mx*Mx;
	My2=My*My;
	amx1=mx1+mx2;
	amy1=my1+my2;
	M2x=(amx1+mx3)/4;
	M2y=(amy1+my3)/4;
	Vx=abs(Mx2-M2x);
	Vy=abs(My2-M2y);
	SDx=(short) sqrt(Vx);
	SDy=(short) sqrt(Vy);
	MSDx=abs(Mx-SDx);
	MSDy=abs(My-SDy);
	DX1=abs(MSDx-x1);
	DX2=abs(MSDx-x2);
	DX3=abs(MSDx-x3);
	DY1=abs(MSDy-y1);
	DY2=abs(MSDy-y2);
	DY3=abs(MSDy-y3);
	D1=DX1+DY1;
	D2=DX2+DY2;
	D3=DX3+DY3;
	N1=abs(x1-y1);		
	N2=abs(x2-y2);		
	N3=abs(x3-y3);	
	Q1=N1/D1;
	Q2=N2/D2;
	Q3=N3/D3;
	aQ1=Q1+Q2;
	aQ2=(aQ1+Q3)/4;	
	NaHiDverc=abs(1-aQ2);	
	return NaHiDverc;
/*

   double mx,my, \
          sdx,sdy,n1,n2,n3, \
          d1,d2,d3,nahid;


       mx=(x1+x2+x3)/3.0;
       my=(y1+y2+y3)/3.0;
       sdx=sqrt( ( (x1-mx)*(x1-mx) + (x2-mx)*(x2-mx) +(x3-mx)*(x3-mx)     )/2.0 );
       sdy=sqrt( ( (y1-my)*(y1-my) + (y2-my)*(y2-my) +(y3-my)*(y3-my)     )/2.0 );
       n1=fabs(x1-y1);
       n2=fabs(x2-y2);
       n3=fabs(x3-y3);
       d1=fabs(fabs(mx-sdx)-x1) + fabs(fabs(my-sdy)-y1);
       d2=fabs(fabs(mx-sdx)-x2) + fabs(fabs(my-sdy)-y2);
       d3=fabs(fabs(mx-sdx)-x3) + fabs(fabs(my-sdy)-y3);
       nahid=fabs( 1.0-(( (n1/d1)+(n2/d2)+(n3/d3) )/3.0) );*/
}

/*
       qmx=mx*mx;
       qmy=my*my;
       mqx=((x1*x1)+(x2*x2)+(x3*x3))/3.0;
       mqy=((y1*y1)+(y2*y2)+(y3*y3))/3.0;

       sdx=sqrt(fabs(mqx-qmx));
       sdy=sqrt(fabs(mqy-qmy));*/
