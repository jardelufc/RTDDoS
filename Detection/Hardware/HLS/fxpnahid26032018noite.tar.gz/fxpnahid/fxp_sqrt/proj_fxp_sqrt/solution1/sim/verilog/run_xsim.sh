
/opt/Xilinx/Vivado/2016.4/bin/xelab xil_defaultlib.apatb_fxp_nahid_top_top -prj fxp_nahid_top.prj --initfile "/opt/Xilinx/Vivado/2016.4/data/xsim/ip/xsim_ip.ini" --lib "ieee_proposed=./ieee_proposed" -s fxp_nahid_top 
/opt/Xilinx/Vivado/2016.4/bin/xsim --noieeewarnings fxp_nahid_top -tclbatch fxp_nahid_top.tcl

