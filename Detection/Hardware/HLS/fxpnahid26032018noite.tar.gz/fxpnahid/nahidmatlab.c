#include <stdio.h>
#include <math.h>

double fxpnahid(double x1,double x2,double x3,double y1, double y2, double y3);

void main(void) {

   
   double x1, x2, x3, y1, y2, y3,z;

   x1=365.0;
   x2=2.52;
   x3=0.9533;
   y1=379.0;
   y2=2.55;
   y3=0.9709;

/*
   x1=357663.0;
   x2=12.79;
   x3=0.94;
   y1=379.0;
   y2=2.55;
   y3=0.9709;*/
 
   z=fxpnahid(x1,x2,x3,y1,y2,y3);
   printf("\n%.16lf\n",z);

}


double fxpnahid(double x1,double x2,double x3,double y1, double y2, double y3)
{
   double mx,my, \
          sdx,sdy,n1,n2,n3, \
          d1,d2,d3,nahid;


       mx=(x1+x2+x3)/3.0;
       my=(y1+y2+y3)/3.0;
       sdx=sqrt( ( (x1-mx)*(x1-mx) + (x2-mx)*(x2-mx) +(x3-mx)*(x3-mx)     )/2.0 );
       sdy=sqrt( ( (y1-my)*(y1-my) + (y2-my)*(y2-my) +(y3-my)*(y3-my)     )/2.0 );
       n1=fabs(x1-y1);
       n2=fabs(x2-y2);
       n3=fabs(x3-y3);
       d1=fabs(fabs(mx-sdx)-x1) + fabs(fabs(my-sdy)-y1);
       d2=fabs(fabs(mx-sdx)-x2) + fabs(fabs(my-sdy)-y2);
       d3=fabs(fabs(mx-sdx)-x3) + fabs(fabs(my-sdy)-y3);
       nahid=fabs( 1.0-(( (n1/d1)+(n2/d2)+(n3/d3) )/3.0) );
}

/*
       qmx=mx*mx;
       qmy=my*my;
       mqx=((x1*x1)+(x2*x2)+(x3*x3))/3.0;
       mqy=((y1*y1)+(y2*y2)+(y3*y3))/3.0;

       sdx=sqrt(fabs(mqx-qmx));
       sdy=sqrt(fabs(mqy-qmy));*/
